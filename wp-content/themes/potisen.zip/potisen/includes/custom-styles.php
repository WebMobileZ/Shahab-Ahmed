<?php
/* Save custom theme styles */
if ( ! function_exists( 'potisen_custom_styles_save' ) ) :
function potisen_custom_styles_save() {

	$main_font = false;
	$main_font_enabled = ( potisen_get_option('main_font_source', 0) == 0 ) ? false : true;
	if ( $main_font_enabled ) {
		$font_main = potisen_get_option('main_font', '');
		if(isset($font_main['font-family']) && $font_main['font-family']){
			$main_font = $font_main['font-family'];
		}
	}

	$secondary_font = false;
	$secondary_font_enabled = ( potisen_get_option('secondary_font_source', 0) == 0 ) ? false : true;
	if ( $secondary_font_enabled ) {
		$font_second = potisen_get_option('secondary_font', '');
		if(isset($font_second['font-family']) && $font_second['font-family']){
			$secondary_font = $font_second['font-family'];
		}
	}

	ob_start();
?>


/* Typography */
<?php if ( $main_font_enabled && isset($main_font) && $main_font ) : ?>
body, .tooltip, .popover, .megamenu-main .widget .widget-title, .megamenu-main .widget .widgettitle, .gva-vertical-menu ul.navbar-nav li a, .gsc-countdown .gva-countdown-inner .countdown-times > div .label,
.post-block-small .post-content .content-inner .entry-title, .gva-countdown .countdown-times > div b
{
	font-family:<?php echo esc_attr( $main_font ); ?>,sans-serif;
}
<?php endif; ?>

<?php if ( $secondary_font_enabled && isset($secondary_font) && $secondary_font ) : ?>
h1, h2, h3, h4, h5, h6, .h1, .h2, .h3, .h4, .h5, .h6,
.elementor-accordion .elementor-accordion-item .elementor-tab-title a, .elementor-widget-progress .elementor-progress-percentage, .gva-hover-box-carousel .hover-box-item .box-content .box-title,
.gsc-countdown .gva-countdown-inner .countdown-times > div, .gsc-countdown .gva-countdown-inner .countdown-times > div b, .gsc-icon-box .highlight_content .title, .gsc-icon-box-carousel.style-1 .icon-box-item-content .title,
.gsc-icon-box-carousel.style-2 .icon-box-item-content .title, .gsc-icon-box-styles.style-1 .icon-box-top .title, .gsc-icon-box-styles.style-2 .icon-box-top .title, .milestone-block.style-1 .box-content .milestone-content .milestone-number-inner, 
.milestone-block.style-2 .box-content .milestone-content .milestone-number-inner, .milestone-block.style-3 .box-content .milestone-content .milestone-number-inner, .gva-testimonial-carousel.style-1 .testimonial-item .testimonial-information span.testimonial-name,
.gva-testimonial-single .tab-carousel-list-here .testimonial-item .testimonial-content .testimonial-content-inner, .gva-testimonial-single .tab-carousel-list-here .testimonial-item .testimonial-video .video-title, .gva-video-carousel .video-item-inner .video-title,
.support-box .title, .event-block-3 .event-content .event-info .title, .event-single .meta-block .block-title, .event-single .meta-block.speakers .speaker-item .name,
.portfolio-filter ul.nav-tabs > li > a, .team-block.team-v1 .team-content .team-name, .team-block.team-v2 .team-content .team-name, .give-block .form-image .content-action .link,
.give-block .form-content .campaign-information > div .c-label, .give-block .form-content .campaign-information .funded .pie-label, .content-single-give-form .give-goal-progress,
.content-single-give-form form[id*=give-form].give-form legend, .content-single-give-form form[id*=give-form].give-form .give-total-wrap .give-donation-amount .give-currency-symbol,
.content-single-give-form form[id*=give-form].give-form .give-total-wrap .give-donation-amount .give-text-input, .content-single-give-form form[id*=give-form].give-form .give-donation-levels-wrap li button,
.mfp-content form[id*=give-form].give-form legend, .mfp-content form[id*=give-form].give-form .give-total-wrap .give-donation-amount .give-currency-symbol, .mfp-content form[id*=give-form].give-form .give-total-wrap .give-donation-amount .give-text-input,
.mfp-content form[id*=give-form].give-form .give-donation-levels-wrap li button, .tweet-2 .ctf-type-usertimeline .ctf-item .ctf-tweet-text, .woocommerce-tabs .nav-tabs > li > a
{
	font-family:<?php echo esc_attr( $secondary_font ); ?>,sans-serif;
}
<?php endif; ?>

/* ----- Main Color ----- */
<?php if($style = potisen_get_option('main_color', '')){ ?>
	body{
		color:<?php echo esc_attr($style) ?>;
	}
<?php } ?>

/* ----- Background body ----- */
<?php 
	$main_background = potisen_get_option('main_background_image', '');
	if(isset($main_background['url']) && $main_background['url']){
?>
body{
	<?php if ( strlen( $main_background['url'] ) > 0 ) : ?>
	background-image:url("<?php echo esc_url( $main_background['url'] ); ?>");
	<?php if ( potisen_get_option('main_background_image_type', '') == 'fixed' ) : ?>
	background-attachment:fixed;
	background-size:cover;
	<?php else : ?>
	background-repeat:repeat;
	background-position:0 0;
	<?php endif; endif; ?>
	background-color:<?php echo esc_attr( potisen_get_option('main_background_color', '') ); ?>;
}
<?php } ?>

/* ----- Main content ----- */
<?php if(potisen_get_option('content_background_color', '')){ ?>
div.page {
	background: <?php echo esc_attr( potisen_get_option('content_background_color', '') ); ?>!important;
}
<?php } ?>

<?php if(potisen_get_option('content_font_color', '')){ ?>
div.page {
	color: <?php echo esc_attr( potisen_get_option('content_font_color', '') ); ?>;
}
<?php } ?>

<?php if(potisen_get_option('content_font_color_link', '')){ ?>
div.page a{
	color: <?php echo esc_attr( potisen_get_option('content_font_color_link', '') ); ?>;
}
<?php } ?>

<?php if(potisen_get_option('content_font_color_link_hover', '')){ ?>
div.page a:hover, div.page a:active, div.page a:focus {
	background: <?php echo esc_attr( potisen_get_option('content_font_color_link_hover', '') ); ?>!important;
}
<?php } ?>

/* ----- Footer content ----- */
<?php if(potisen_get_option('footer_background_color', '')){ ?>
#wp-footer {
	background: <?php echo esc_attr( potisen_get_option('footer_background_color', '') ); ?>!important;
}
<?php } ?>

<?php if(potisen_get_option('footer_font_color', '')){ ?>
#wp-footer {
	color: <?php echo esc_attr( potisen_get_option('footer_font_color', '') ); ?>;
}
<?php } ?>

<?php if(potisen_get_option('footer_font_color_link', '')){ ?>
#wp-footer a{
	color: <?php echo esc_attr( potisen_get_option('footer_font_color_link', '') ); ?>;
}
<?php } ?>

<?php if(potisen_get_option('footer_font_color_link_hover', '')){ ?>
#wp-footer a:hover, #wp-footer a:active, #wp-footer a:focus {
	background: <?php echo esc_attr( potisen_get_option('footer_font_color_link_hover', '') ); ?>!important;
}
<?php } ?>

/* ----- Breacrumb Style ----- */

<?php
	$styles = ob_get_clean();
	
    $styles = preg_replace( '!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $styles );
	
	$styles = str_replace( array( "\r\n", "\r", "\n", "\t", '  ', '   ', '    ' ), '', $styles );
		
	update_option( 'potisen_theme_custom_styles', $styles, true );
}
endif;

add_action( 'redux/options/potisen_theme_options/saved', 'potisen_custom_styles_save' );


/* Make sure custom theme styles are saved */
function potisen_custom_styles_install() {
	if ( ! get_option( 'potisen_theme_custom_styles' ) && get_option( 'potisen_theme_options' ) ) {
		potisen_custom_styles_save();
	}
}

add_action( 'redux/options/potisen_theme_options/register', 'potisen_custom_styles_install' );
