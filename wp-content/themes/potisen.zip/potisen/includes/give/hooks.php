<?php
if(!function_exists('potisen_give_breadcrumb')){
   function potisen_give_breadcrumb(){
      $result = potisen_style_breadcrumb();
      extract($result);
      if(isset($no_breadcrumbs) && $no_breadcrumbs == true){
         echo '<div class="disable-breadcrumb clearfix"></div>';
         return false;
      }
      ?>
         <div class="custom-breadcrumb <?php echo implode(' ', $classes); ?>" <?php echo(count($styles) > 0 ? 'style="' . implode(';', $styles) . '"' : ''); ?>>
          <?php if($styles_overlay){ ?>
             <div class="breadcrumb-overlay" style="<?php echo esc_attr($styles_overlay); ?>"></div>
          <?php } ?>
          <div class="breadcrumb-main">
            <div class="container">
              <div class="breadcrumb-container-inner">
                <?php if($title && ( $show_page_title || empty($show_page_title) ) ){ 
                  echo '<h2 class="heading-title">' . esc_html( $title ) . '</h2>';
                } ?>
                <?php potisen_general_breadcrumbs(); ?>
              </div>  
            </div>   
          </div>  
       </div>
      <?php
   }
   add_action( 'potisen_give_before_main_content', 'potisen_give_breadcrumb', 20 );
}

function potisen_give_change_posts_per_page( $query ) {
   if ( is_admin() || ! $query->is_main_query() ) {
      return;
   }
   $posts_per_page = potisen_get_option('give_posts_per_page', 6);
   if ( is_post_type_archive( 'give_forms' ) ) {
      $query->set( 'posts_per_page', $posts_per_page );
   }
}
add_filter( 'pre_get_posts', 'potisen_give_change_posts_per_page' );

function potisen_give_get_donation_form_submit_button( $form_id ) {
  $display_label_field = give_get_meta( $form_id, '_give_checkout_label', true );
  $display_label       = ( ! empty( $display_label_field ) ? $display_label_field : esc_html__( 'Donate Now', 'potisen' ) );
  ob_start();
  ?>
  <div class="give-submit-button-wrap give-clearfix">
    <button type="submit" class="give-submit give-btn" id="give-purchase-button" name="give-purchase" value="<?php echo esc_attr($display_label); ?>" data-before-validation-label="<?php echo esc_attr($display_label); ?>">
         <?php echo esc_html($display_label); ?>
    </button>
    <span class="give-loading-animation"></span>
  </div>
  <?php
  return ob_get_clean();
}
add_filter( 'give_donation_form_submit_button', 'potisen_give_get_donation_form_submit_button');

function potisen_give_display_checkout_button( $output ) {
  $output = '<div class="clearfix give-btn-checkout">'.$output.'</div>';
  echo wp_kses( $output, true );
}

add_filter( 'give_display_checkout_button', 'potisen_give_display_checkout_button');