<?php
 /**
 *
 * @package    basetheme
 * @author     Gaviasthemes Team     
 * @copyright  Copyright (C) 2018 Gaviasthemes. All Rights Reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * 
 */ 

/*
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
 */
if ( post_password_required() ) {
    return;
}
?>

<div id="comments" class="comments-area">
    <?php if ( have_comments() ) { ?>
        <h2 class="comments-title">
            <?php
                printf( _nx( 'One thought on &ldquo;%2$s&rdquo;', '%1$s thoughts on &ldquo;%2$s&rdquo;', get_comments_number(), 'comments title', 'potisen' ),
                    number_format_i18n( get_comments_number() ), get_the_title() );
            ?>
        </h2>
        
        <div class="gav-comment-list clearfix">
          
          <ol class="pingbacklist">
            <?php
                wp_list_comments( array( 'type' => 'pingback', 'short_ping'  => true ) );
            ?>
         </ol>
          <ol class="comment-list">
              <?php wp_list_comments('type=comment&callback=potisen_comment_template'); ?>
          </ol>
          <?php
          if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) :
          ?>
          <footer class="navigation comment-navigation" role="navigation">
              <div class="previous"><?php previous_comments_link( esc_html__( '&larr; Older Comments', 'potisen') ); ?></div>
              <div class="next right"><?php next_comments_link( esc_html__( 'Newer Comments &rarr;', 'potisen') ); ?></div>
          </footer>
          <?php endif; ?>

          <?php if ( ! comments_open() && get_comments_number() ) : ?>
              <p class="no-comments"><?php echo esc_html__( 'Comments are closed.' , 'potisen'); ?></p>
          <?php endif; ?>
        </div>
    <?php } ?>

    <?php
        // If comments are closed and there are comments, let's leave a little note, shall we?
        if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) :
    ?>
        <p class="no-comments"><?php esc_html__( 'Comments are closed.', 'potisen' ); ?></p>
    <?php endif; ?>

    <?php comment_form(); ?>

</div><!-- .comments-area -->
