<?php
  $form_id = get_the_ID();
  $form = new Give_Donate_Form( $form_id );
  $progress_stats = give_goal_progress_stats($form);
  $income = 0;
  $goal = '';

  $goal_option = give_get_meta( $form_id, '_give_goal_option', true );
  if($goal_option == 'disabled' || !$goal_option){
    $goal = 'unlimited';
    $progress = 100;
    $income = isset($progress_stats['actual']) ? $progress_stats['actual'] : 0;
  }

  if($goal == 'unlimited'){
    $progress_label = esc_html__( 'unlimited' , 'potisen' );
    $progress = 100;
  }else{
    $progress = isset($progress_stats['progress']) ? $progress_stats['progress'] : 100;
    $progress_label = $progress . '%';
    $income = isset($progress_stats['actual']) ? $progress_stats['actual'] : 0;
    $goal = isset($progress_stats['goal']) ? $progress_stats['goal'] : 0;
    if($progress > 100) $progress = 100;
  }

  if(!isset($excerpt_words)){
    $excerpt_words = potisen_get_option('give_excerpt_limit', 10);
  }
  
?> 
<div  class="give-block" >
  <div <?php post_class(); ?>>
    <div class="form-image">
      <?php if ( has_post_thumbnail() ) { ?>
        <a href="<?php the_permalink() ?>"><?php the_post_thumbnail( 'medium' ); ?></a>
      <?php } else { ?>
       <a href="<?php the_permalink() ?>"><img src="<?php echo esc_url(get_template_directory_uri() . '/images/no-image.jpg'); ?>" alt="<?php echo the_title_attribute() ?>"/></a>
      <?php } ?>
      <div class="content-action"><a class="link" href="<?php the_permalink() ?>"><?php echo esc_html__( 'Donation now', 'potisen' ) ?></a></div>
      <?php get_template_part( 'give/part', 'gallery' ); ?>
      <?php get_template_part( 'give/part', 'video' ); ?>
    </div>
    <div class="form-content">
      <div class="funded">
        <div class="give__progress">
          <div class="give__progress-bar" data-progress-max="<?php echo esc_attr($progress)?>%">
            <?php if($progress > 75){ ?>
              <span class="percentage percentage-left"><?php echo esc_html($progress_label); ?></span>
            <?php }else{ ?>
              <span class="percentage"><?php echo esc_html($progress_label); ?></span>
            <?php } ?>  
          </div>
        </div>
      </div>

      <div class="form-content-inner">
        <?php if($goal == 'unlimited'){ ?>
          <div class="campaign-information unlimited">
            <div class="campaign-raised"> 
              <span class="c-label"><?php echo esc_html__('Raised', 'potisen') ?></span> 
              <span class="raised"><?php echo esc_html($income) ?></span>
            </div>
            <div class="campaign-goal"> 
              <span class="c-label"><?php echo esc_html__('Goal', 'potisen') ?></span> 
              <span class="goal"><?php echo esc_html($progress_label) ?></span>
            </div>
          </div>
        <?php }else{ ?>
          <div class="campaign-information">
            <div class="campaign-raised"> 
              <span class="c-label"><?php echo esc_html__('Raised', 'potisen') ?></span> 
              <span class="raised"><?php echo esc_html($income) ?></span>
            </div>
            <div class="funded">
              <span class="pie-label"><?php echo esc_attr($progress_label)?></span>
            </div>
            <div class="campaign-goal"> 
              <span class="c-label"><?php echo esc_html__('Goal', 'potisen') ?></span> 
              <span class="goal"><?php echo esc_html($goal) ?></span>
            </div>
          </div>
        <?php } ?>  

        <h2 class="title"><a href="<?php the_permalink() ?>"><?php the_title() ?></a></h2>
        <div class="desc"><?php echo potisen_limit_words( $excerpt_words, get_the_excerpt(), get_the_content() ); ?></div>
        <div class="campaign-action"><a class="btn-give-theme" href="<?php the_permalink() ?>"><?php echo esc_html__('Read more', 'potisen') ?></a></div>

      </div>  
     </div>
  </div>
</div>

