<?php
  $form_id = get_the_ID();
  $form = new Give_Donate_Form( $form_id );
  $progress_stats = give_goal_progress_stats($form);
  $income = 0;
  $goal = '';

  $goal_option = give_get_meta( $form_id, '_give_goal_option', true );
  if($goal_option == 'disabled' || !$goal_option){
    $goal = 'unlimited';
    $progress = 100;
    $income = isset($progress_stats['actual']) ? $progress_stats['actual'] : 0;
  }

  if($goal == 'unlimited'){
    $progress_label = esc_html__( 'unlimited' , 'potisen' );
    $progress = 100;
  }else{
    $progress = isset($progress_stats['progress']) ? $progress_stats['progress'] : 100;
    $progress_label = $progress . '%';
    $income = isset($progress_stats['actual']) ? $progress_stats['actual'] : 0;
    $goal = isset($progress_stats['goal']) ? $progress_stats['goal'] : 0;
    if($progress > 100) $progress = 100;
  }

  if(!isset($excerpt_words)){
    $excerpt_words = potisen_get_option('give_excerpt_limit', 10);
  }
  
?> 
<div  class="give-block-simple">
  <div <?php post_class(); ?>>
    <div class="form-content">
      <div class="form-content-inner">
        <h2 class="title"><a href="<?php the_permalink() ?>"><?php the_title() ?></a></h2>
        <div class="give-form-inner">
          <?php give_get_donation_form( array('show_title' =>false, 'id' => $form_id, 'display_style' => 'modal', 'continue_button_title' => 'Donate', 'float_labels' => 'global', 'show_content' => 'none') ) ?>
        </div>
      </div>  
     </div>
  </div>
</div>

