  <?php get_header(); ?>
  <section class="static-banner-one">
            <div class="static-banner-one__bg">
                <div class="static-banner-one__bg-inner"></div><!-- /.static-banner-one__bg-inner -->
            </div><!-- /.static-banner-one__bg -->
            <div class="container">
                <h6 class="static-banner-one__title">
                    Let us Provide Strong Effective <br>Leadership for our Country, <br/> <span class="typed-effect" id="type-1" data-strings="For our Michigan"></span>
                </h6>
               <?php echo get_field('banner_description'); ?>
                <form class="static-banner-one__form mc-form" data-url="#">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="static-banner-one__form-fields ">
                            <a href="<?php echo site_url('contact'); ?>" class="thm-btn static-banner-one__form-btn">Contact US</a>
                        </div><!-- /.col-lg-6 -->
                    </div><!-- /.row -->
               
                <div class="mc-form__response"></div><!-- /.mc-form__response -->
            </div><!-- /.container -->
		</form>
	  </div>
     </section><!-- /.static-banner-one -->
        
        <section class="about-three thm-gray-bg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="about-three__image">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/resources/mission-vision.jpg" alt="Awesome Image" />
                        </div><!-- /.about-three__image -->
                    </div><!-- /.col-lg-6 -->
                    <div class="col-lg-6">
                        <div class="about-three__content">
                            <div class="block-title text-left">
                            
                                <h2 class="block-title__title">  <?php echo get_field('mission_title'); ?></h2><!-- /.block-title__title -->
                            </div><!-- /.block-title -->
                            <div class="about-three__box-wrap">
                                <div class="about-three__box">
									 <i class="potisen-icon-work"></i>
                                   
                                    <h4 class="about-three__box-title"> <?php echo get_field('mission_icon_1_title'); ?></h4><!-- /.about-three__box-title -->
                                </div><!-- /.about-three__box -->
                                <div class="about-three__box">
                                    <i class="potisen-icon-politics"></i>
                                    <h4 class="about-three__box-title"> <?php echo get_field('mission_icon_2_title'); ?></h4><!-- /.about-three__box-title -->
                                </div><!-- /.about-three__box -->
                                <div class="about-three__box">
                                   
									  <i class="potisen-icon-bid"></i>
                                    <h4 class="about-three__box-title"> <?php echo get_field('mission_icon_3_title'); ?> </h4><!-- /.about-three__box-title -->
                                </div><!-- /.about-three__box -->
								
                            </div><!-- /.about-three__box-wrap -->
							   <!--<div class="about-three__box-wrap">
                                <div class="about-three__box">
									 <i class="potisen-icon-work"></i>
                                   
                                    <h4 class="about-three__box-title"> Nature Protection</h4>
                                </div>
                                <div class="about-three__box">
                                    <i class="potisen-icon-politics"></i>
                                    <h4 class="about-three__box-title"> Senior Citizen and Disabled Support </h4>
                                </div>
                                <div class="about-three__box">
                                   
									  <i class="potisen-icon-bid"></i>
                                    <h4 class="about-three__box-title"> Upcoming Covid Effect Management</h4>
                                </div>
								
                            </div> -->
							        
                          <?php echo get_field('mission_description'); ?><!-- /.about-three__text -->
                            <a href="<?php echo site_url('visionandmission'); ?>" class="thm-btn about-three__btn">Learn More</a>
                        </div><!-- /.about-three__content -->
                    </div><!-- /.col-lg-6 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.about-three -->
        
        <section class="about-two">
            <div class="container">
                <div class="block-title text-center">
                    <p class="block-title__tag-line">About</p>
                    <h2 class="block-title__title"><?php echo get_field('after_mission_section_title'); ?></h2><!-- /.block-title__title -->
                </div><!-- /.block-title -->
                <div class="row">
                    <div class="col-lg-6">
                        <div class="about-two__content">
                            <div class="row">
                                <div class="col-sm-4">
                                    <img src="<?php echo get_field('history_image_1'); ?>" alt="" class="img-fluid" />
                                </div><!-- /.col-sm-4 -->
                                <div class="col-sm-4">
                                    <img src="<?php echo get_field('history_image_2'); ?>" alt="" class="img-fluid" />
                                </div><!-- /.col-sm-4 -->
                                <div class="col-sm-4">
                                    <img src="<?php echo get_field('history_image_3'); ?>" alt="" class="img-fluid" />
                                </div><!-- /.col-sm-4 -->
                            </div><!-- /.row -->
                           <?php echo get_field('history_description'); ?><!-- /.about-two__text -->
							 <a href="<?php echo site_url('about'); ?>" class="thm-btn about-three__btn">Learn More</a>
                        </div><!-- /.about-two__content -->
                    </div><!-- /.col-lg-6 -->
                    <div class="col-lg-6">
                        <div class="accrodion-grp" data-grp-name="faq-accrodion">
                            <div class="accrodion active">
                                <div class="accrodion-title">
                                    <h4>  <?php echo get_field('faq_1_title'); ?></h4>
                                </div>
                                <div class="accrodion-content">
                                    <div class="inner">
                                       <?php echo get_field('faq_1_content'); ?>
											
                                    </div><!-- /.inner -->
                                </div>
                            </div>
                            <div class="accrodion ">
                                <div class="accrodion-title">
                                    <h4> <?php echo get_field('faq_2_title'); ?></h4>
                                </div>
                                <div class="accrodion-content">
                                    <div class="inner">
                                       <?php echo get_field('faq_2_content'); ?>
                                    </div><!-- /.inner -->
                                </div>
                            </div>
                            <div class="accrodion">
                                <div class="accrodion-title">
                                    <h4>  <?php echo get_field('faq_3_title'); ?></h4>
                                </div>
                                <div class="accrodion-content">
                                    <div class="inner">
                                         <?php echo get_field('faq_3_content'); ?>
                                    </div><!-- /.inner -->
                                </div>
                            </div>
							 <div class="accrodion">
                                <div class="accrodion-title">
                                    <h4>  <?php echo get_field('faq_4_title'); ?></h4>
                                </div>
                                <div class="accrodion-content">
                                    <div class="inner">
                                         <?php echo get_field('faq_4_content'); ?>
										
                                    </div><!-- /.inner -->
                                </div>
                            </div>
                        </div>
                    </div><!-- /.col-lg-6 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.about-two -->
        
       
 <?php get_footer(); ?>
<script>
      if ($('.static-banner-one__bg').length) {
            $('.static-banner-one__bg-inner').vegas({
                slides: [
                    { src: "<?php echo get_template_directory_uri(); ?>/assets/images/background/banner-bg-1-1.jpg" },
                    { src: "<?php echo get_template_directory_uri(); ?>/assets/images/background/banner-bg-1-2.jpg" }
                ],
                transition: 'slideUp',
                timer: false
            });
        }
</script>