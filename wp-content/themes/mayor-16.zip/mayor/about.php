<?php 

/*
Template Name:About
*/
get_header();
?>

        <section class="inner-banner">
            <div class="container">
                <h2 class="inner-banner__title"><?php the_title(); ?></h2><!-- /.inner-banner__title -->
                <ul class="list-unstyled thm-breadcrumb">
                    <li><a href="<?php echo site_url(''); ?>">Home</a></li>
                    <li><?php the_title(); ?></li>
                </ul><!-- /.list-unstyled -->
            </div><!-- /.container -->
        </section><!-- /.inner-banner -->
        <section class="thm-gray-bg about-one">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 wow fadeInUp" data-wow-duration="1500ms">
                        <img src="<?php echo get_field('gallery_image_1'); ?>" alt="Image">
                    </div><!-- /.col-lg-6 -->
                    <div class="col-lg-6 wow fadeInUp" data-wow-duration="1500ms">
                        <img src="<?php echo get_field('gallery_image_2'); ?>" alt="Image" />
                    </div><!-- /.col-lg-6 -->
                </div><!-- /.row -->
                <div class="block-title text-center">
                    
                   <!-- <p class="block-title__tag-line"><?php echo get_field('about_section_1_title'); ?> </p> -->
                    <h2 class="block-title__title"><?php echo get_field('about_section_1_sub_title'); ?>  </h2><!-- /.block-title__title -->
                </div><!-- /.block-title -->
             <?php echo get_field('about_section_1_content'); ?>  
            </div><!-- /.container -->
        </section><!-- /.thm-gray-bg about-one -->

     

<?php             
$post = get_post(get_the_ID()); 
if($post->post_content !=''){
?>
          <section class="history-one">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        
                        <?php
         $post = get_post(get_the_ID()); 
$content = apply_filters('the_content', $post->post_content); 
echo $content;  
                      ?>
                    </div>
                </div>
            </div>
        </section>
        <?php } ?>
   

        
<?php get_footer(); ?>