<?php 

/*
Template Name:Vision & Mission
*/
get_header();
?>
 <section class="inner-banner">
            <div class="container">
                <h2 class="inner-banner__title"><?php the_title(); ?></h2><!-- /.inner-banner__title -->
                <ul class="list-unstyled thm-breadcrumb">
                    <li><a href="<?php echo site_url(''); ?>">Home</a></li>
                    <li><?php the_title(); ?></li>
                </ul><!-- /.list-unstyled -->
            </div><!-- /.container -->
        </section><!-- /.inner-banner -->
  <section class="history-one">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="history-one__single wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">
                            <div class="history-one__image">
                                <div class="history-one__image-inner"><img alt="" src=" <?php echo get_field('mission_image'); ?>"></div><!-- /.history-one__image-inner -->
                            </div><!-- /.history-one__image -->
                            <div class="history-one__content">
                                <h3 class="history-one__title">
                                  <?php echo get_field('mission_title'); ?>
                                </h3>
                                <?php echo get_field('mission_content'); ?>
                            </div><!-- /.history-one__content -->
                        </div><!-- /.history-one__single -->
                        <div class="history-one__single wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">
                            
                            <div class=" history-one__image">
                                <h3 class="history-one__title">
                                    <?php echo get_field('vision_title'); ?>
                                </h3>
                              <?php echo get_field('vision_content'); ?>
                            </div><!-- /.history-one__content -->
                            <div class="history-one__content">
                                <div class="history-one__image-inner"><img alt="" src=" <?php echo get_field('vision_image'); ?>"></div><!-- /.history-one__image-inner -->
                            </div><!-- /.history-one__image -->
                        </div><!-- /.history-one__single -->
                        
                        
                    </div><!-- /.col-lg-12 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section>
        <?php             
$post = get_post(get_the_ID()); 
if($post->post_content !=''){
?>
          <section class="history-one">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        
                        <?php
         $post = get_post(get_the_ID()); 
$content = apply_filters('the_content', $post->post_content); 
echo $content;  
                      ?>
                    </div>
                </div>
            </div>
        </section>
        <?php } ?>
<?php get_footer(); ?>